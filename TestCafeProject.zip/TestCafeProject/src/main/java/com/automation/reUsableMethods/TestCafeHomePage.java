package com.automation.reUsableMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestCafeHomePage extends DriverInitialization {
	
	WebDriver driver;
	
	private By name=By.id("developer-name");
	private By populateBtn=By.id("populate");
	
	private By windowsRadioBtn=(By.cssSelector("input[value='Windows']"));
	private By macOSRadioBtn=(By.cssSelector("input[value='MacOS']"));
	private By linuxRadioBtn=(By.cssSelector("input[value='Linux']"));
	
	private By remoteTestingCheckBox=By.id("remote-testing");
	private By reusingJsCodeCheckBox=By.id("reusing-js-code");
	private By parallelTestingCheckBox=By.id("background-parallel-testing");
	private By continousIntegerationCheckBox=By.id("continuous-integration-embedding");
	private By trafficMarkUpCheckBox=By.id("traffic-markup-analysis");
	
	private By interfaceOptions=By.id("preferred-interface");
	private By testCafeCheckBox=By.id("tried-test-cafe");
	private By sliderBar=By.xpath("//div[@id='slider']/span");
	private By commentsTextBox=By.id("comments");
	private By submitBtn=By.id("submit-button");
	
	private By headerMsg=By.id("article-header");
	
	public TestCafeHomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public WebElement getName()
	{
		return driver.findElement(name);
	}
	
	public WebElement getPopulateBtn()
	{
		return driver.findElement(populateBtn);
	}
	
	public WebElement getwindowsRadioBtn()
	{
		return driver.findElement(windowsRadioBtn);
	}
	
	public WebElement getmacOSRadioBtn()
	{
		return driver.findElement(macOSRadioBtn);
	}
	
	public WebElement getlinuxRadioBtn()
	{
		return driver.findElement(linuxRadioBtn);
	}
	
	public WebElement getremoteTestingCheckBox()
	{
		return driver.findElement(remoteTestingCheckBox);
	}
	
	public WebElement getreusingJsCodeCheckBox()
	{
		return driver.findElement(reusingJsCodeCheckBox);
	}
	
	public WebElement getparallelTestingCheckBox()
	{
		return driver.findElement(parallelTestingCheckBox);
	}
	
	public WebElement getcontinousIntegerationCheckBox()
	{
		return driver.findElement(continousIntegerationCheckBox);
	}
	
	public WebElement gettrafficMarkUpCheckBox()
	{
		return driver.findElement(trafficMarkUpCheckBox);
	}
	
	public WebElement gettestCafeCheckBox()
	{
		return driver.findElement(testCafeCheckBox);
	}
	
	public WebElement getcommentsTextBox()
	{
		return driver.findElement(commentsTextBox);
	}
	
	public WebElement getsubmitBtn()
	{
		return driver.findElement(submitBtn);
	}
	
	public WebElement getsliderBar()
	{
		return driver.findElement(sliderBar);
	}
	
	public WebElement getinterfaceOptions()
	{
		return driver.findElement(interfaceOptions);
	}
	
	public WebElement getHeaderMessage()
	{
		return driver.findElement(headerMsg);
	}

	

}
