package stepDefinitions;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.automation.reUsableMethods.DriverInitialization;
import com.automation.reUsableMethods.TestCafeHomePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class StepDefinition extends DriverInitialization {
	
	TestCafeHomePage p;

	@Given("Initialize the browser")
	public void initialize_the_browser() throws IOException {
	  driver=InitializeDriver();
	}
	@Given("Navigate to TestCafe site")
	public void navigate_to_TestCafe_site() {
	    // navigating to given url
	    driver.get(prop.getProperty("Url"));
	}
	@When("I Enter {string} in editbox and click on populate button")
	public void i_enter_in_editbox_and_click_on_populate_button(String name) {
	
		//Enter name into the edit box
		p=new TestCafeHomePage(driver);
		p.getName().sendKeys(name);
		
		//clicking on populate button
		p.getPopulateBtn().click();
		
	}
	    
	@Then("the alert got displayed and clicked on {string} button")
	public void the_alert_got_displayed_and_clicked_on_button(String string) {
		// switched to alert and clicked on cancel button
		if(string.equalsIgnoreCase("OK"))
		{	
			driver.switchTo().alert().accept();
		}
		else
		{
			driver.switchTo().alert().dismiss();
		}
	    
	}
	
	
	@Then("selected {string} as primary operating system")
	public void selected_as_primary_operating_system(String os) {
	    // selecting windows as operating system
		if(os.equalsIgnoreCase("Windows"))
		{
			p.getwindowsRadioBtn().click();
			System.out.println("windows selected");
		}
		else if(os.equalsIgnoreCase("MacOS"))
		{
			p.getmacOSRadioBtn().click();
			System.out.println("MacOs selected");
		}
		else if(os.equalsIgnoreCase("Linux"))
		{
			p.getlinuxRadioBtn().click();
			System.out.println("Linux selected");
		}
	}
	@Then("check the features which are important")
	public void check_the_features_which_are_important() {
	    // selecting the important features
		p.getcontinousIntegerationCheckBox().click();
		p.getparallelTestingCheckBox().click();
		p.getremoteTestingCheckBox().click();
		p.getreusingJsCodeCheckBox().click();
	}
	@When("selected {string} interface")
	public void selected_interface(String string) {
	    // Write code here that turns the phrase above into concrete actions
	   WebElement options=p.getinterfaceOptions();
	   
	   Select dropdown= new Select(options);
	   
	   // select by visible of the text
	   dropdown.selectByVisibleText("JavaScript API");
	}
	@When("select on I have tried TestCafe checkbox")
	public void select_on_i_have_tried_test_cafe_checkbox() {
	    // selected I have tried Testcafe checkbox
	    p.gettestCafeCheckBox().click();
	}
	@When("rate the TestCafe")
	public void rate_the_test_cafe() {

		WebElement slider=p.getsliderBar();
		
		Actions action=new Actions(driver);
		action.dragAndDropBy(slider, 750, 0).build().perform();
		
	}
	@When("give {string} in the comments sections")
	public void give_in_the_comments_sections(String comment) {
	   p.getcommentsTextBox().sendKeys(comment);
	}
	@When("I clicked on submit button")
	public void i_clicked_on_submit_button() {
	    // click on submit button
		p.getsubmitBtn().click();
	   
	}
	@Then("verify the thank you page is displayed")
	public void verify_the_thank_you_page_is_displayed() {
		String expectedMsg=p.getHeaderMessage().getText();
		if(expectedMsg.contains("Thank you"))
			System.out.println("Page is successfully submitted and Thank youpage is displayed");
		else
			System.out.println("Page is not submitted successfully");
	
	}
	@Then("close all the browsers")
	public void close_all_the_browsers() {
		 driver.quit();
	}
}
