# QE NE Digital Pretest

  You can answer it as creative as you can, you can even show off what you know, use all the tools that you like, and send us your PR.
Once upon a time there is a web page (https://devexpress.github.io/testcafe/example/) that need to assess how cool is the quality of the page. And here it comes your first task begin:


1. Tell us what kind of test should be conduct (plan and why) to make sure the page is ok.

	a. Unit Testing - Done by developer
	b.Integration testing
	c.Regression Tesing - done if some changes comes after delivery
	d.Smoke testing - to test partilly when partly feature is delivered
	e.System Testing- complete E2E testing
	f.Stress Testing -Test cases that require maximum memory or other resources are executed
	g.Performance Testing - To validate the system performance when the no of users increases


2. Tell us what kind of testcase you want to execute.

	a. Unit test cases - written by developer to make sure nothing is broken
	b. UI Test cases (Integration Test) - these are functional test cases
	c. System Test cases - E2E scenario , those are functionlly performed 
	d. Performance Test - if application need to be tested for no of virtual users then we can use Load runner or Jmeter to make sure it   is working correctly if load increases.
	e. Security testing - Need to perform if any vulnerability check or Authentication check is required 

3. Running in local

	> set terminal to root of this project and run below command.
	> mvn install/test
	
	After successful build, can see test results in target/cucumber-reports.html file.

4. Every new employee at NTUC will have a buddy help him/her to tune in with environment. Every employee have their supervisor and team. Let's say that we have a table of employee where all the information mention earlier is store. The table specification is looks like this:<BR>
| employee_id | employee_name | buddy_id | supervisor_id | team_name |<BR>
your task is to create a query to show:<BR>
| employee_id | employee_name | buddy_name | supervisor_name | team_name |

	>	Select employee_id,employee_name,buddy_name,supervisor_name,team_name from employee e1,employee e2
		Where
		e1.employee_id=e2.employee_id and e1.supervisor_id=e2.supervisor_id and e1.Team_name=e2.Team_name
